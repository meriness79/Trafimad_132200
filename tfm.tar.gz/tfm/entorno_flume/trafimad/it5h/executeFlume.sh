#!/usr/bin/env bash
#ALUMNO: 132200
#Aplication: trafimad_it5h

/home/nsanchez/entorno_flume/apache-flume-1.9.0-bin/bin/flume-ng agent \
   -f /home/nsanchez/entorno_flume/trafimad/it5h/conf/flume.conf \
   --name agent \
   -Dflume.root.logger=INFO,console

#################################################################################################################
## Para enviar datos:
##  
##  $> Ejecuta script flume path:
##     Source path file: /home/nsanchez/entorno_flume/trafimad/it5h/conf/flume.conf
##     Sink Hbase
####################################################################################################################

