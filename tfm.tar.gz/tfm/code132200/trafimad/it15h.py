import os
from datetime import datetime
from io import BytesIO
from zipfile import ZipFile
from urllib import urlopen

#ALUMNO: 132200
#Aplication: Trafimad_it15h
#version: 1.0.0
#Ejemplo enlaces de como se compone la url de datos origen de las descargas de datos
#201910 -->https://datos.madrid.es/egob/catalogo/208627-77-transporte-ptomedida-historico.zip
#201811 -->https://datos.madrid.es/egob/catalogo/208627-66-transporte-ptomedida-historico.zip
#Description: descarga de la url, descomprime el zip y lo escribe en un csv de salida los datos de intensidad mensual 15 min
now = datetime.now()
date_time = now.strftime("%Y-%m-%d")
fechaCarga = now.strftime("%Y-%m-%d %H:%M:%S")
#Sacamos el numero de mensualidad que toca publicar con la diferencia de meses y teniendo en cuenta si el dia de ejecucion es < 15
mes=67
#Descarga el fichero del url publica
url="https://datos.madrid.es/egob/catalogo/208627-"+str(mes)+"-transporte-ptomedida-historico.zip"
resp = urlopen(url)
count=0
#Definimos el limite de la secuencia de meses de ficheros de resgitros mensuales de intensidad que se quiere descarga,
while mes<68:
 #Descomprime y lee el fichero csv y lo escribe en el directorio local para luego ser movido al directorio de flume
 with ZipFile(BytesIO(resp.read())) as zipfile:
      for data_file in zipfile.namelist():
           with open(("/home/nsanchez/tfm/code132200/trafimad/data_files/it15/pmm_" + data_file), "wb") as output:
            for line in zipfile.open(data_file).readlines():
               line= fechaCarga+';'+line.replace('"','')
               sihead=line.find('id')
               if sihead>0:
                  print line
               else:
                 output.write(line)
                 count=count+1
 fichero="/home/nsanchez/tfm/code132200/trafimad/data_files/it15/pmm_" + data_file
 #Mostramos el numero de registros
 print data_file
 print count
 os.system("mv "+fichero+" -t  '/home/nsanchez/entorno_flume/trafimad/data_files/it15f/'")
 mes=mes+1


