import os
from datetime import datetime
from io import BytesIO
from zipfile import ZipFile
from urllib import urlopen

# or: requests.get(url).content

#ALUMNO: 132200
#Aplication: Trafimad_it15h
#version: 1.0.0
#Description: descarga de la url, descomprime el zip y lo escribe en un csv de salida los datos de intensidad mensual 15 min
now = datetime.now()
date_time = now.strftime("%Y-%m-%d")
fechaCarga = now.strftime("%Y-%m-%d %H:%M:%S")
#Obtenemos la secuencia mensual del fichero mas actual que hay publicado a partir de la fecha actual y el primer fichero publicado
d1 = datetime.strptime(date_time,'%Y-%m-%d')
#Primer fecha de publicacion del historico de intensidad de trafico, necesaria para obtener la secuencia del fichero mas actual a publicar
d2 = datetime.strptime('2013-06-01', '%Y-%m-%d')
#Sacamos el numero de mensualidad que toca publicar con la diferencia de meses y teniendo en cuenta si el dia de ejecucion es < 15
if d1.day < 15:
  mes = (d1.year - d2.year) * 12 + (d1.month-1) - d2.month
else:
  mes = (d1.year - d2.year) * 12 + d1.month - d2.month
print mes
#Descarga el fichero del url publica
url="https://datos.madrid.es/egob/catalogo/208627-"+str(mes)+"-transporte-ptomedida-historico.zip"
resp = urlopen(url)
count=0
#Descomprime y lee el fichero csv y lo escribe en el directorio local para luego ser movido al directorio de flume
with ZipFile(BytesIO(resp.read())) as zipfile:
      for data_file in zipfile.namelist():
           with open(("/home/nsanchez/tfm/code132200/trafimad/data_files/it15/pmm_" + data_file), "wb") as output:
            for line in zipfile.open(data_file).readlines():
               line= fechaCarga+';'+line.replace('"','')
               sihead=line.find('id')
               if sihead>0:
                  print line
               else: 
                  output.write(line)
                  count=count+1

fichero="/home/nsanchez/tfm/code132200/trafimad/data_files/it15/pmm_" + data_file
print count
os.system("mv "+fichero+" -t  '/home/nsanchez/entorno_flume/trafimad/data_files/it5f/'")
