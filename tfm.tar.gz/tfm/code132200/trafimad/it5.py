import requests
import xml.etree.ElementTree as ET
from lxml import etree
import time
import sys
import re
import csv
from datetime import datetime

# -*- coding: utf-8 -*-

#ALUMNO: 132200
#Aplication: Trafimad_it5
#version: 1.0.0
#description: It5: descarga fichero intensidad publicado cada 5 minutos desde http://informo.munimadrid.es/informo/tmadrid/pm.xml  
#recorre los elementos de datos y los escribe en hbase
#fecha, idelem, descripcion, accesoAsociado, intensidad, ocupacion, carga, nivelServicio, intensidadSat, velocidad, error, subarea, stx,sty fecput, idproceso
#Se carga el xml obtenido de la url fuente en la variable doc de tipo etree
doc = etree.parse("http://informo.munimadrid.es/informo/tmadrid/pm.xml")
pms=doc.getroot()
fecha=pms[0]
fecha= datetime.strptime(fecha.text,"%d/%m/%Y %H:%M:%S")

#Preparamos fichero salida
path="/home/nsanchez/tfm/code132200/trafimad/data_files/it5h/IT5H_"
now = datetime.now()
date_time = now.strftime("%Y%m%d_%H%M%S")
fechaCarga = now.strftime("%Y-%m-%d %H:%M:%S") 
fichero=path+date_time+'.csv'

# open a file for writing

data = open(fichero, 'w')

# create the csv writer object

csvwriter = csv.writer(data, delimiter="|")
data_head = []

count = 0
for member in pms.findall('pm'):
        pm= []
	if count == 0:
                rowkey= u'rowkey'
                data_head.append(rowkey)
		idelem = member.find('idelem').tag
		data_head.append(idelem.encode("utf-8"))
		if member.find('descripcion') is None:
                  descripcion=u'descripcion'
                else:
                  descripcion = member.find('descripcion').tag
                data_head.append(descripcion.encode("utf-8"))
		if member.find('accesoAsociado') is None:
                   accesoAsociado=u'accesoAsociado'
                else:
                   accesoAsociado = member.find('accesoAsociado').tag
                data_head.append(accesoAsociado.encode("utf-8"))
		intensidad = member.find('intensidad').tag
                data_head.append(intensidad.encode("utf-8"))
                ocupacion = member.find('ocupacion').tag
                data_head.append(ocupacion.encode("utf-8"))
                carga = member.find('carga').tag
                data_head.append(carga.encode("utf-8"))
                nivelServicio = member.find('nivelServicio').tag
                data_head.append(nivelServicio.encode("utf-8"))
                if member.find('intensidadSat') is None:
                   intensidadSat=u'intensidadSat'
                else:
                   intensidadSat = member.find('intensidadSat').tag
                data_head.append(intensidadSat.encode("utf-8"))
                if member.find('velocidad') is None:
                   velocidad = u'velocidad'
                else:
                   velocidad = member.find('velocidad').tag
                data_head.append(velocidad.encode("utf-8"))
                error = member.find('error').tag
                data_head.append(error.encode("utf-8"))
                if member.find('subarea') is None:
                   subarea=u'subarea'
                else:
                   subarea = member.find('subarea').tag
                data_head.append(subarea.encode("utf-8"))
                st_x = member.find('st_x').tag
                data_head.append(st_x.encode("utf-8"))
                st_y = member.find('st_y').tag
                data_head.append(st_y.encode("utf-8"))
                #fecha_carga= u'fecha_actualizacion'
                #data_head.append(fecha_carga)
                fechaDatos= u'fechadatos'
                data_head.append(fechaDatos)
                #csvwriter.writerow(data_head)
		count = count + 1
        rowkey = member.find('st_x').text+'-'+member.find('st_y').text
        pm.append(rowkey.encode("utf-8"))
        idelem = member.find('idelem').text
	pm.append(idelem.encode("utf-8"))
	if member.find('descripcion') is None:
           descripcion = u'INTERURBANO'
        else:
           descripcion = member.find('descripcion').text
        pm.append(descripcion.encode("utf-8"))
	if member.find('accesoAsociado') is None:
           accesoAsociado = u'0'
        else:
           accesoAsociado = member.find('accesoAsociado').text
        pm.append(accesoAsociado)
	intensidad = member.find('intensidad').text
        pm.append(intensidad.encode("utf-8"))
        ocupacion = member.find('ocupacion').text
        pm.append(ocupacion.encode("utf-8"))
        carga = member.find('carga').text
        pm.append(carga.encode("utf-8"))
        if member.find('nivelServicio') is None:
           nivelServicio = u'0'
        else:
           nivelServicio = member.find('nivelServicio').text
        pm.append(nivelServicio)
        if member.find('intensidadSat') is None:
           intensidadSat= u'0'
        else:
            intensidadSat = member.find('intensidadSat').text
        pm.append(intensidadSat.encode("utf-8"))
        if member.find('velocidad') is None:
           velocidad = u'0'
        else:
           velocidad = member.find('velocidad').text
        pm.append(velocidad)
        error = member.find('error').text
        pm.append(error)
        if member.find('subarea') is None:
          subarea = u'0'
        else:
          subarea = member.find('subarea').text
        pm.append(subarea.encode("utf-8"))
        st_x = member.find('st_x').text
        pm.append(st_x.encode("utf-8"))
        st_y = member.find('st_y').text
        pm.append(st_y.encode("utf-8"))
        pm.append(fecha)
        csvwriter.writerow(pm)
data.close()

