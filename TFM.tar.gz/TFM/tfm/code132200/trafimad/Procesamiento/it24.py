import os
import csv
import re
from datetime import datetime
from io import BytesIO

# -*- coding: utf-8 -*-

#ALUMNO: 132200
#Aplication: Trafimad_it24
#version: 1.0.0
#Description: lee el fichero csv exportado de hive llamado it24 y le quita las líneas de la cabecera y lo dejaen otro fichero csv de salida
now = datetime.now()
anio = str(now.year)
fechaCarga = now.strftime("%Y-%m-%d %H:%M:%S")
print anio
inputfile = '/home/nsanchez/file/it24.csv'
outputfile ="/home/nsanchez/it24.csv"
#Abre,lee el fichero csv y lo escribe en el directorio temporal y cuando finaliza lo mueve al directorio de flume especifico 
count=0
with open(inputfile) as csvfile:
    reader = csv.reader(csvfile, delimiter='|')
    with open(outputfile, "w") as output:
     for line in csvfile:
        if count==0 or count==2:
          print line
        else:
          output.write(line)
        count=count+1
print count

