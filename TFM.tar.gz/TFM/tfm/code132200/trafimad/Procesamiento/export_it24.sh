hive -e "select fecha, anio, mes, dia, 
avg_ocupacion, max_ocupacion, min_ocupacion,
avg_intensidad, max_intensidad, min_intensidad,
avg_carga, max_carga, min_carga,
avg_vmed, max_vmed, min_vmed,       
num_diasemana, dia_semana, si_finde_semana, si_festivo_nacional,
si_festivo_comunidad, si_festivo_local, tipo_festivo, festividad,
idelem, tipo_elem, distrito_idelem, nombre_idelem, 
longitud_idelem, latitud_idelem
from intensidades_dia " > /home/nsanchez/file/it24.csv ;
#Ejecutmos el script que limpia lineas cabecera hive y deposita el
#fichero de salida en la ruta /home/nsanchez/file/it24.csv
python /home/nsanchez/tfm/code132200/trafimad/it24.py

