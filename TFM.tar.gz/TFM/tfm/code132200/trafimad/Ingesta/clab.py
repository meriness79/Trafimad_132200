import os
import csv
import re
from datetime import datetime
from io import BytesIO
from zipfile import ZipFile
from urllib import urlopen

# -*- coding: utf-8 -*-

#ALUMNO: 132200
#Aplication: Trafimad_clab
#version: 1.0.0
#Description: descarga de la url, el fichero csv del calendario laboral anual y lo escribe en un csv de salida
now = datetime.now() 
anio = str(now.year)
fechaCarga = now.strftime("%Y-%m-%d %H:%M:%S")
print anio
url="https://datos.madrid.es/egob/catalogo/300082-0-calendario_laboral.csv"
resp = urlopen(url)
fichero="/home/nsanchez/tfm/code132200/trafimad/data_files/clab/calendario_laboral.csv"
#Abre,lee el fichero csv y lo escribe en el directorio temporal y cuando finaliza lo mueve al directorio de flume especifico 
with BytesIO(resp.read()) as csvfile:
       for data_file in csvfile:
           with open(fichero, "wb") as output:
            for line in csvfile:
               #line= fechaCarga+';'+line
               sihead=line.find('dia')
               if sihead>0:
                  print line
               else: 
                  output.write(line)
                  count=count+1
print count
os.system("mv "+fichero+" -t  '/home/nsanchez/entorno_flume/trafimad/data_files/clabf/'")
