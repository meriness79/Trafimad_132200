import requests
import xml.etree.ElementTree as ET
from lxml import etree
import time
import sys
import re
import csv
from datetime import datetime

#ALUMNO: 132200
#Aplication: Trafimad_in5
#version: 1.0.0

#Se carga el xml obtenido de la url fuente en la variable doc de tipo etree
# -*- coding: utf-8 -*-

doc = etree.parse("http://informo.munimadrid.es/informo/tmadrid/incid_aytomadrid.xml")
incidencias=doc.getroot()

#Preparamos fichero salida
path="/home/nsanchez/tfm/code132200/trafimad/data_files/in5/IN5_"
now = datetime.now()
date_time = now.strftime("%Y%m%d_%H%M%S")
fecha_carga = now.strftime("%Y-%m-%d %H:%M:%S") 
fichero=path+date_time+'.csv'
# open a file for writing

data = open(fichero, 'w')

# create the csv writer object

csvwriter = csv.writer(data, delimiter="|")
data_head = []

count = 0
for member in incidencias.findall('Incidencia'):
        incidencia= []
	if count == 0:
                id_incidencia = member.find('id_incidencia').tag
		data_head.append(id_incidencia.encode("utf-8"))	
                codigo = member.find('codigo').tag
                data_head.append(codigo.encode("utf-8"))
		cod_tipo_incidencia = member.find('cod_tipo_incidencia').tag
                data_head.append(cod_tipo_incidencia.encode("utf-8"))
		nom_tipo_incidencia = member.find('nom_tipo_incidencia').tag
                data_head.append(nom_tipo_incidencia.encode("utf-8"))
                fh_inicio = member.find('fh_inicio').tag
                data_head.append(fh_inicio.encode("utf-8"))
                fh_final = member.find('fh_final').tag
                data_head.append(fh_final.encode("utf-8"))
                incid_prevista = member.find('incid_prevista').tag
                data_head.append(incid_prevista.encode("utf-8"))
                incid_planificada = member.find('incid_planificada').tag
                data_head.append(incid_planificada.encode("utf-8"))
                incid_estado = member.find('incid_estado').tag
                data_head.append(incid_estado.encode("utf-8"))
                descripcion = member.find('descripcion').tag
                data_head.append(descripcion.encode("utf-8"))
                utm_x = member.find('utm_x').tag
                data_head.append(utm_x.encode("utf-8"))
                utm_y = member.find('utm_y').tag
                data_head.append(utm_y.encode("utf-8"))
                longitud = member.find('longitud').tag
                data_head.append(longitud.encode("utf-8"))
                latitud = member.find('latitud').tag
                data_head.append(latitud.encode("utf-8"))
                es_obras = member.find('es_obras').tag
                data_head.append(es_obras.encode("utf-8"))
                es_accidente = member.find('es_accidente').tag
                data_head.append(es_accidente.encode("utf-8"))
                es_contaminacion = member.find('es_contaminacion').tag
                data_head.append(es_contaminacion.encode("utf-8"))
                escenarioutm_y = member.find('utm_y').tag
                data_head.append(utm_y.encode("utf-8"))
                if member.find('escenario_contaminacion') is None:
                  escenario_contaminacion = u'escenario_contaminacion'
                else:
                  escenario_contaminacion = member.find('fecha_escenario_contaminacion').text
                data_head.append(escenario_contaminacion)
                if member.find('fecha_escenario_contaminacion') is None:
                  fecha_escenario_contaminacion = u'fecha_escenario_contaminacion'
                else:
                  fecha_escenario_contaminacion = member.find('fecha_escenario_contaminacion').text
                data_head.append(fecha_escenario_contaminacion)
                if member.find('descripcion_escenario') is None:
                  descripcion_escenario_contaminacion = u'descripcion_escenario'
                else:
                  descripcion_escenario = member.find('descripcion_escenario').text
                data_head.append(descripcion_escenario)
                if member.find('medidas_escenario') is None:
                  medidas_escenario = u'medidas_escenario'
                else:
                  medidas_escenario = member.find('medidas_escenario').text
                data_head.append(medidas_escenario)
                if member.find('excepciones_escenario') is None:
                  excepcion_escenario = u'excepciones_escenario'
                else:
                  excepciones_escenario = member.find('excepciones_escenario').text
                data_head.append(excepciones_escenario)
                data_head.append(fecha_carga)                
                #csvwriter.writerow(data_head)
		count = count + 1
        id_incidencia = member.find('id_incidencia').text
        incidencia.append(id_incidencia.encode("utf-8"))
	codigo = member.find('codigo').text
        incidencia.append(codigo.encode("utf-8"))
        cod_tipo_incidencia = member.find('cod_tipo_incidencia').text
        incidencia.append(cod_tipo_incidencia.encode("utf-8"))
        nom_tipo_incidencia = member.find('nom_tipo_incidencia').text
        incidencia.append(nom_tipo_incidencia.encode("utf-8"))
        fh_inicio = member.find('fh_inicio').text
        incidencia.append(fh_inicio.encode("utf-8"))
        fh_final = member.find('fh_final').text
        incidencia.append(fh_final.encode("utf-8"))
        incid_prevista = member.find('incid_prevista').text
        incidencia.append(incid_prevista.encode("utf-8"))
        incid_planificada = member.find('incid_planificada').text
        incidencia.append(incid_planificada.encode("utf-8"))
        incid_estado = member.find('incid_estado').text
        incidencia.append(incid_estado.encode("utf-8"))
        descripcion = member.find('descripcion').text
        incidencia.append(descripcion.encode("utf-8"))
        utm_x = member.find('utm_x').text
        incidencia.append(utm_x.encode("utf-8"))
        utm_y = member.find('utm_y').text
        incidencia.append(utm_y.encode("utf-8"))
        longitud = member.find('longitud').text
        incidencia.append(longitud.encode("utf-8"))
        latitud = member.find('latitud').text
        incidencia.append(latitud.encode("utf-8"))
        tipoincid = member.find('tipoincid').text
        incidencia.append(tipoincid.encode("utf-8"))
        es_obras = member.find('es_obras').text
        incidencia.append(es_obras.encode("utf-8"))
        es_accidente = member.find('es_accidente').text
        incidencia.append(es_accidente.encode("utf-8"))
        es_contaminacion = member.find('es_contaminacion').text
        incidencia.append(es_contaminacion.encode("utf-8"))
        if member.find('escenario_contaminacion') is None:
           escenario_contaminacion = u'0'
        else:
           escenario_contaminacion = member.find('escenario_contaminacion').text
        incidencia.append(escenario_contaminacion)
        if member.find('fecha_escenario_contaminacion') is None:
           fecha_escenario_contaminacion= u'0'
        else:
           fecha_escenario_contaminacion = member.find('fecha_escenario_contaminacion').text
        incidencia.append(fecha_escenario_contaminacion)
        if member.find('descripcion_escenario') is None:
           descripcion_escenario = u'0'
        else:
           descripcion_escenario = member.find('descripcion_escenario').text
        incidencia.append(descripcion_escenario)
        if member.find('medidas_escenario').text is None:
          medidas_escenario = u'0'
        else:
          medidas_escenario = member.find('medidas_escenario').text
        incidencia.append(medidas_escenario)
        if member.find('excepciones_escenario').text is None:
          excepciones_escenario = u'0'
        else:
          excepciones_escenario = member.find('excepciones_escenario').text
        incidencia.append(excepciones_escenario)        
        incidencia.append(fecha_carga)
	csvwriter.writerow(incidencia)
data.close()

