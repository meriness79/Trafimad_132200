from datetime import datetime
import os
import csv
import urllib
import requests
from io import BytesIO
from urllib import urlopen
import re

# -*- coding: utf-8 -*-

#ALUMNO: 132200
#Aplication: Trafimad_pmed
#version: 1.0.0
#Description: descarga de la url, el csv de los datos de ubicacion de los puntos de medicion y los guarda en el directorio de salida
now = datetime.now()      
date_time = now.strftime("%Y-%m-%d")
fechaCarga = now.strftime("%Y-%m-%d %H:%M:%S")
#Obtenemos la secuencia del fichero mensual que hay colgado a partir de la fecha actual y el primer fichero publicado
d1 = datetime.strptime(date_time,'%Y-%m-%d')
#Primer fecha de publicacion del historico de intensidad de trafico
d2 = datetime.strptime('2019-09-01', '%Y-%m-%d')
#Obtiene la secuencia del fichero publicado, dependiendo si se ejecuta antes del dia 15 sera el del mes anterior a la fecha ejecucion
if d1.day > 15:
  mes = (d1.year - d2.year) * 12 + d1.month - d2.month
else:
  mes = (d1.year - d2.year) * 12 + (d1.month-1) - d2.month
mes = 52 + (mes)*3 
print mes
file_mes = str(d1.year) + str(d1.month-1)
#Descarga el fichero del url publica
url="https://datos.madrid.es/egob/catalogo/202468-"+str(mes)+"-intensidad-trafico.csv"
resp = urlopen(url)
#Abre,lee el fichero csv y lo escribe en el directorio temporal y cuando finaliza lo mueve al directorio de flume especifico 
count=0
fichero="/home/nsanchez/tfm/code132200/trafimad/data_files/pmed/pmed_"+file_mes+".csv"
with BytesIO(resp.read()) as csvfile:
      for data_file in csvfile:
           with open(fichero, "wb") as output:
            for line in csvfile:
               line=fechaCarga+';'+line.replace('"','')
               output.write(line)
               count=count+1
print count
os.system("mv "+fichero+" -t  '/home/nsanchez/entorno_flume/trafimad/data_files/pmedf/'")

