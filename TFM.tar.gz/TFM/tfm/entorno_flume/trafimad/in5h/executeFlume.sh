#!/usr/bin/env bash
#ALUMNO: 132200
#Aplication: trafimad_in5h

/home/nsanchez/entorno_flume/apache-flume-1.9.0-bin/bin/flume-ng agent \
   -f /home/nsanchez/entorno_flume/trafimad/in5h/conf/flume.conf \
   --name Agent1 \
   -Dflume.root.logger=INFO,console

#################################################################################################################
## Para enviar datos:
##  
##  $> Ejecuta script flume path:
##     Source path file: /home/nsanchez/entorno_flume/trafimad/in5h/conf/flume.conf
##     Sink Hbase: hdfs dfs -ls /user/nsanchez/trafimad/in5h
####################################################################################################################
~                                                                                                                        
