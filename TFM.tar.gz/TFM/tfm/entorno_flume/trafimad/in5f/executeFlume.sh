#!/usr/bin/env bash
#ALUMNO: 132200
#Aplication: trafimad_in5f

/home/nsanchez/entorno_flume/apache-flume-1.9.0-bin/bin/flume-ng agent \
   -f /home/nsanchez/entorno_flume/trafimad/in5f/conf/flume.conf \
   --name Agent1 \
   -Dflume.root.logger=INFO,console

#################################################################################################################
## Para enviar datos:
##  
##  $> Ejecuta script flume path:
##     Source path file: /home/nsanchez/entorno_flume/trafimad/in5f/conf/flume.conf
##     Sink Hdfs: hdfs dfs -ls /user/nsanchez/trafimad/in5f
####################################################################################################################

